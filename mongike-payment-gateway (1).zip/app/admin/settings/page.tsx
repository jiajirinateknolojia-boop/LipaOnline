'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatCurrency } from '@/lib/mongike'

export default function AdminSettingsPage() {
  const withdrawalTiers = [
    { max: 100000, fee: 3000 },
    { max: 200000, fee: 5000 },
    { max: 300000, fee: 7000 },
    { max: 400000, fee: 9000 },
    { max: 500000, fee: 11000 },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Mipangilio</h2>
        <p className="text-muted-foreground">
          Mipangilio ya mfumo wa LipaOnline
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Ada za Muamala</CardTitle>
            <CardDescription>Ada zinazochukuliwa kwa kila muamala</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div>
                <p className="font-medium">Ada ya Mauzo</p>
                <p className="text-sm text-muted-foreground">Inachukuliwa kwa kila muamala uliokamilika</p>
              </div>
              <Badge variant="secondary" className="text-lg">2%</Badge>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div>
                <p className="font-medium">Commission ya Mualikaji</p>
                <p className="text-sm text-muted-foreground">Anapata kila mauzo ya aliyemualika</p>
              </div>
              <Badge variant="secondary" className="text-lg">0.5%</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Usajili wa Custom Branding</CardTitle>
            <CardDescription>Bei za usajili wa branding maalum</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div>
                <p className="font-medium">Kila Mwezi</p>
                <p className="text-sm text-muted-foreground">Malipo ya kila mwezi</p>
              </div>
              <Badge variant="secondary" className="text-lg">{formatCurrency(1000)}</Badge>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div>
                <p className="font-medium">Kila Mwaka</p>
                <p className="text-sm text-muted-foreground">Malipo ya kila mwaka (punguzo)</p>
              </div>
              <Badge variant="secondary" className="text-lg">{formatCurrency(10000)}</Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Ada za Kutoa Pesa</CardTitle>
            <CardDescription>Ada kulingana na kiasi cha kutoa</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
              {withdrawalTiers.map((tier, index) => {
                const minAmount = index === 0 ? 1000 : withdrawalTiers[index - 1].max + 1
                return (
                  <div key={tier.max} className="rounded-lg border p-4 text-center">
                    <p className="text-sm text-muted-foreground">
                      {formatCurrency(minAmount)} - {formatCurrency(tier.max)}
                    </p>
                    <p className="mt-2 text-2xl font-bold">{formatCurrency(tier.fee)}</p>
                    <p className="text-xs text-muted-foreground">ada</p>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Muunganisho wa Malipo</CardTitle>
            <CardDescription>API ya Mongike kwa Mobile Money</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg bg-muted p-4">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-green-500" />
                <span className="font-medium">Mongike API</span>
                <Badge>Imeunganishwa</Badge>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">
                Malipo ya M-Pesa, TigoPesa, na Airtel Money yanashughulikiwa kupitia Mongike Push API
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
