'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { ChevronLeft, ChevronRight, CheckCircle, XCircle, Loader2 } from 'lucide-react'
import { formatCurrency } from '@/lib/mongike'
import { format } from 'date-fns'
import type { Withdrawal } from '@/lib/types'

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  approved: 'bg-blue-100 text-blue-800',
  processing: 'bg-purple-100 text-purple-800',
  completed: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
}

const statusLabels: Record<string, string> = {
  pending: 'Inasubiri',
  approved: 'Imekubaliwa',
  processing: 'Inachakatwa',
  completed: 'Imekamilika',
  rejected: 'Imekataliwa',
}

export default function AdminWithdrawalsPage() {
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [loading, setLoading] = useState(true)
  const [processing, setProcessing] = useState(false)
  const [status, setStatus] = useState('all')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Withdrawal | null>(null)
  const [adminNote, setAdminNote] = useState('')

  useEffect(() => {
    fetchWithdrawals()
  }, [page, status])

  async function fetchWithdrawals() {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '20',
        status,
      })
      const res = await fetch(`/api/admin/withdrawals?${params}`)
      const data = await res.json()
      setWithdrawals(data.withdrawals || [])
      setTotalPages(data.totalPages || 1)
    } catch (error) {
      console.error('Failed to fetch withdrawals:', error)
    } finally {
      setLoading(false)
    }
  }

  async function processWithdrawal(newStatus: 'completed' | 'rejected') {
    if (!selectedWithdrawal) return
    
    setProcessing(true)
    try {
      await fetch('/api/admin/withdrawals', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedWithdrawal.id,
          status: newStatus,
          admin_note: adminNote,
        }),
      })
      setSelectedWithdrawal(null)
      setAdminNote('')
      fetchWithdrawals()
    } catch (error) {
      console.error('Failed to process withdrawal:', error)
    } finally {
      setProcessing(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Kutoa Pesa</h2>
        <p className="text-muted-foreground">
          Simamia maombi ya kutoa pesa kutoka kwa wafanyabiashara
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Maombi ya Kutoa Pesa</CardTitle>
            <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="Hali" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Zote</SelectItem>
                <SelectItem value="pending">Inasubiri</SelectItem>
                <SelectItem value="completed">Imekamilika</SelectItem>
                <SelectItem value="rejected">Imekataliwa</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex h-32 items-center justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            </div>
          ) : withdrawals.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Hakuna maombi yaliyopatikana
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mfanyabiashara</TableHead>
                      <TableHead>Kiasi</TableHead>
                      <TableHead>Ada</TableHead>
                      <TableHead>Mteja Atapata</TableHead>
                      <TableHead>Simu</TableHead>
                      <TableHead>Hali</TableHead>
                      <TableHead>Tarehe</TableHead>
                      <TableHead className="w-24"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {withdrawals.map((withdrawal) => (
                      <TableRow key={withdrawal.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{withdrawal.merchant?.shop_name}</p>
                            <p className="text-xs text-muted-foreground">{withdrawal.merchant?.phone}</p>
                          </div>
                        </TableCell>
                        <TableCell>{formatCurrency(withdrawal.amount)}</TableCell>
                        <TableCell>{formatCurrency(withdrawal.fee)}</TableCell>
                        <TableCell className="font-medium">{formatCurrency(withdrawal.net_amount)}</TableCell>
                        <TableCell>{withdrawal.phone}</TableCell>
                        <TableCell>
                          <Badge className={statusColors[withdrawal.status] || ''} variant="outline">
                            {statusLabels[withdrawal.status] || withdrawal.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {format(new Date(withdrawal.created_at), 'dd/MM/yyyy HH:mm')}
                        </TableCell>
                        <TableCell>
                          {withdrawal.status === 'pending' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedWithdrawal(withdrawal)}
                            >
                              Chukua Hatua
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              <div className="mt-4 flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Ukurasa {page} kati ya {totalPages}
                </p>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    disabled={page === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Process Withdrawal Dialog */}
      <Dialog open={!!selectedWithdrawal} onOpenChange={() => setSelectedWithdrawal(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Chukua Hatua kwa Ombi</DialogTitle>
            <DialogDescription>
              Ombi la {formatCurrency(selectedWithdrawal?.amount || 0)} kutoka {selectedWithdrawal?.merchant?.shop_name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="rounded-lg bg-muted p-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Kiasi:</span>
                <span className="font-medium">{formatCurrency(selectedWithdrawal?.amount || 0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ada:</span>
                <span>{formatCurrency(selectedWithdrawal?.fee || 0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Mteja atapata:</span>
                <span className="font-bold">{formatCurrency(selectedWithdrawal?.net_amount || 0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Simu:</span>
                <span className="font-mono">{selectedWithdrawal?.phone}</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Maelezo (Hiari)</label>
              <Textarea
                placeholder="Weka maelezo kama unahitaji..."
                value={adminNote}
                onChange={(e) => setAdminNote(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="destructive"
              onClick={() => processWithdrawal('rejected')}
              disabled={processing}
            >
              {processing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <XCircle className="mr-2 h-4 w-4" />}
              Kataa
            </Button>
            <Button
              onClick={() => processWithdrawal('completed')}
              disabled={processing}
            >
              {processing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
              Kamilisha
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
