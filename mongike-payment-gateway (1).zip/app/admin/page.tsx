'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Users, 
  ShoppingCart, 
  TrendingUp, 
  Wallet,
  Package,
  Clock,
  CheckCircle,
  ArrowUpRight
} from 'lucide-react'
import { formatCurrency } from '@/lib/mongike'

interface DashboardStats {
  totalMerchants: number
  activeMerchants: number
  totalProducts: number
  totalOrders: number
  completedOrders: number
  totalRevenue: number
  platformFees: number
  pendingWithdrawals: number
  todayOrders: number
  todayRevenue: number
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [])

  async function fetchStats() {
    try {
      const res = await fetch('/api/admin/stats')
      const data = await res.json()
      setStats(data)
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  if (!stats) {
    return (
      <div className="text-center text-muted-foreground">
        Imeshindwa kupakia takwimu
      </div>
    )
  }

  const statCards = [
    {
      title: 'Wafanyabiashara',
      value: stats.totalMerchants,
      subValue: `${stats.activeMerchants} hai`,
      icon: Users,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10',
    },
    {
      title: 'Bidhaa',
      value: stats.totalProducts,
      icon: Package,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10',
    },
    {
      title: 'Maagizo',
      value: stats.totalOrders,
      subValue: `${stats.completedOrders} yamekamilika`,
      icon: ShoppingCart,
      color: 'text-orange-500',
      bgColor: 'bg-orange-500/10',
    },
    {
      title: 'Mapato Jumla',
      value: formatCurrency(stats.totalRevenue),
      icon: TrendingUp,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
    },
    {
      title: 'Ada ya Jukwaa (2%)',
      value: formatCurrency(stats.platformFees),
      icon: Wallet,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-500/10',
    },
    {
      title: 'Kutoa Pesa Kunasubiri',
      value: formatCurrency(stats.pendingWithdrawals),
      icon: Clock,
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/10',
    },
    {
      title: 'Maagizo Leo',
      value: stats.todayOrders,
      icon: CheckCircle,
      color: 'text-cyan-500',
      bgColor: 'bg-cyan-500/10',
    },
    {
      title: 'Mapato Leo',
      value: formatCurrency(stats.todayRevenue),
      icon: ArrowUpRight,
      color: 'text-pink-500',
      bgColor: 'bg-pink-500/10',
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Muhtasari wa biashara yako
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <div className={`rounded-lg p-2 ${stat.bgColor}`}>
                  <Icon className={`h-4 w-4 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                {stat.subValue && (
                  <p className="text-xs text-muted-foreground">{stat.subValue}</p>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
