'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { 
  Search, 
  MoreHorizontal, 
  CheckCircle, 
  XCircle,
  Shield,
  ChevronLeft,
  ChevronRight
} from 'lucide-react'
import { formatCurrency } from '@/lib/mongike'
import type { Merchant } from '@/lib/types'

export default function AdminMerchantsPage() {
  const [merchants, setMerchants] = useState<Merchant[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  useEffect(() => {
    fetchMerchants()
  }, [page, search])

  async function fetchMerchants() {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '20',
        search,
      })
      const res = await fetch(`/api/admin/merchants?${params}`)
      const data = await res.json()
      setMerchants(data.merchants || [])
      setTotalPages(data.totalPages || 1)
    } catch (error) {
      console.error('Failed to fetch merchants:', error)
    } finally {
      setLoading(false)
    }
  }

  async function toggleMerchantStatus(id: string, isActive: boolean) {
    try {
      await fetch('/api/admin/merchants', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, is_active: !isActive }),
      })
      fetchMerchants()
    } catch (error) {
      console.error('Failed to update merchant:', error)
    }
  }

  async function toggleVerification(id: string, isVerified: boolean) {
    try {
      await fetch('/api/admin/merchants', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, is_verified: !isVerified }),
      })
      fetchMerchants()
    } catch (error) {
      console.error('Failed to update merchant:', error)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Wafanyabiashara</h2>
        <p className="text-muted-foreground">
          Simamia wafanyabiashara wote kwenye jukwaa
        </p>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Orodha ya Wafanyabiashara</CardTitle>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Tafuta..."
                className="pl-9"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(1)
                }}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex h-32 items-center justify-center">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            </div>
          ) : merchants.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Hakuna wafanyabiashara waliopatikana
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Duka</TableHead>
                      <TableHead>Mmiliki</TableHead>
                      <TableHead>Simu</TableHead>
                      <TableHead>Salio</TableHead>
                      <TableHead>Mauzo</TableHead>
                      <TableHead>Hali</TableHead>
                      <TableHead className="w-12"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {merchants.map((merchant) => (
                      <TableRow key={merchant.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {merchant.shop_name}
                            {merchant.is_verified && (
                              <Shield className="h-4 w-4 text-blue-500" />
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{merchant.full_name}</TableCell>
                        <TableCell>{merchant.phone}</TableCell>
                        <TableCell>{formatCurrency(merchant.wallet_balance)}</TableCell>
                        <TableCell>{formatCurrency(merchant.total_sales)}</TableCell>
                        <TableCell>
                          <Badge variant={merchant.is_active ? 'default' : 'secondary'}>
                            {merchant.is_active ? 'Hai' : 'Imezimwa'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={() => toggleVerification(merchant.id, merchant.is_verified)}
                              >
                                {merchant.is_verified ? (
                                  <>
                                    <XCircle className="mr-2 h-4 w-4" />
                                    Ondoa Uthibitisho
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle className="mr-2 h-4 w-4" />
                                    Thibitisha
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => toggleMerchantStatus(merchant.id, merchant.is_active)}
                              >
                                {merchant.is_active ? (
                                  <>
                                    <XCircle className="mr-2 h-4 w-4" />
                                    Zima
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle className="mr-2 h-4 w-4" />
                                    Washa
                                  </>
                                )}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              <div className="mt-4 flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Ukurasa {page} kati ya {totalPages}
                </p>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    disabled={page === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
