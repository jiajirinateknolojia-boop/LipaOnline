"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Store, Package, ArrowLeft, Phone, User, MapPin, CheckCircle2, Loader2, AlertCircle } from "lucide-react"

interface ProductData {
  id: string
  name: string
  description: string | null
  price: number
  image_url: string | null
  product_type: string
  stock_quantity: number
  merchant: {
    id: string
    shop_name: string
    full_name: string
    is_verified: boolean
    branding_color: string | null
    custom_branding: boolean
  }
}

type PaymentStep = "form" | "processing" | "success" | "error"

export default function ProductPage() {
  const params = useParams()
  const shopName = params.shopName as string
  const productSlug = params.productSlug as string

  const [product, setProduct] = useState<ProductData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  const [buyerName, setBuyerName] = useState("")
  const [buyerPhone, setBuyerPhone] = useState("")
  const [buyerLocation, setBuyerLocation] = useState("")
  const [paymentPhone, setPaymentPhone] = useState("")
  const [usePhoneForPayment, setUsePhoneForPayment] = useState(true)

  const [paymentStep, setPaymentStep] = useState<PaymentStep>("form")
  const [paymentMessage, setPaymentMessage] = useState("")
  const [orderKey, setOrderKey] = useState("")

  useEffect(() => {
    async function fetchProduct() {
      try {
        const res = await fetch(`/api/shop/${shopName}/${productSlug}`)
        const data = await res.json()
        if (!res.ok) throw new Error(data.error)
        setProduct(data)
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : "Bidhaa haipatikani")
      } finally {
        setLoading(false)
      }
    }
    fetchProduct()
  }, [shopName, productSlug])

  async function handlePurchase(e: React.FormEvent) {
    e.preventDefault()
    if (!product) return

    setPaymentStep("processing")
    setPaymentMessage("Inatuma ombi la malipo...")

    try {
      const res = await fetch("/api/payment/push", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: product.id,
          buyerName,
          buyerPhone,
          buyerLocation,
          paymentPhone: usePhoneForPayment ? buyerPhone : paymentPhone,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.error || "Kosa limetokea")
      }

      setOrderKey(data.orderKey)
      setPaymentMessage(data.message || "Ombi la malipo limetumwa! Tafadhali angalia simu yako na weka PIN.")
      setPaymentStep("success")
    } catch (err: unknown) {
      setPaymentMessage(err instanceof Error ? err.message : "Kosa limetokea")
      setPaymentStep("error")
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-lg mx-auto">
          <Skeleton className="h-64 w-full mb-6" />
          <Skeleton className="h-8 w-3/4 mb-2" />
          <Skeleton className="h-6 w-1/2 mb-4" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    )
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6 text-center">
            <Package className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h1 className="text-xl font-bold mb-2">Bidhaa Haipatikani</h1>
            <p className="text-muted-foreground mb-4">{error}</p>
            <Link href={`/shop/${shopName}`} className="text-primary hover:underline">
              Rudi Dukani
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const brandColor = product.merchant.custom_branding && product.merchant.branding_color 
    ? product.merchant.branding_color 
    : "#10b981"

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div 
        className="py-4 px-6"
        style={{ backgroundColor: brandColor }}
      >
        <div className="max-w-lg mx-auto">
          <Link 
            href={`/shop/${shopName}`}
            className="inline-flex items-center gap-2 text-white/90 hover:text-white text-sm"
          >
            <ArrowLeft className="h-4 w-4" />
            {product.merchant.shop_name}
          </Link>
        </div>
      </div>

      <div className="max-w-lg mx-auto p-6">
        {/* Product Image */}
        <div className="aspect-square relative bg-muted rounded-lg overflow-hidden mb-6">
          {product.image_url ? (
            <Image
              src={product.image_url}
              alt={product.name}
              fill
              className="object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Package className="h-20 w-20 text-muted-foreground" />
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="mb-6">
          <div className="flex items-start justify-between gap-4 mb-2">
            <h1 className="text-2xl font-bold">{product.name}</h1>
            {product.merchant.is_verified && (
              <Badge variant="secondary" className="shrink-0">
                <Store className="h-3 w-3 mr-1" />
                Imethibitishwa
              </Badge>
            )}
          </div>
          <p 
            className="text-3xl font-bold mb-4"
            style={{ color: brandColor }}
          >
            TZS {product.price.toLocaleString()}
          </p>
          {product.description && (
            <p className="text-muted-foreground">{product.description}</p>
          )}
          {product.stock_quantity !== -1 && (
            <p className="text-sm text-muted-foreground mt-2">
              Kiasi kilichobaki: {product.stock_quantity}
            </p>
          )}
        </div>

        {/* Purchase Form */}
        {paymentStep === "form" && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Nunua Sasa</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePurchase} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    <User className="h-4 w-4 inline mr-1" />
                    Jina Lako
                  </Label>
                  <Input
                    id="name"
                    value={buyerName}
                    onChange={(e) => setBuyerName(e.target.value)}
                    placeholder="Jina lako kamili"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">
                    <Phone className="h-4 w-4 inline mr-1" />
                    Namba ya Simu
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={buyerPhone}
                    onChange={(e) => setBuyerPhone(e.target.value)}
                    placeholder="0712345678"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">
                    <MapPin className="h-4 w-4 inline mr-1" />
                    Mahali (Mkoa/Wilaya)
                  </Label>
                  <Input
                    id="location"
                    value={buyerLocation}
                    onChange={(e) => setBuyerLocation(e.target.value)}
                    placeholder="Dar es Salaam, Kinondoni"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="usePhone"
                      checked={usePhoneForPayment}
                      onChange={(e) => setUsePhoneForPayment(e.target.checked)}
                      className="rounded"
                    />
                    <Label htmlFor="usePhone" className="text-sm cursor-pointer">
                      Tumia namba hii kwa malipo
                    </Label>
                  </div>

                  {!usePhoneForPayment && (
                    <div className="space-y-2">
                      <Label htmlFor="paymentPhone">
                        Namba ya Kulipa (M-Pesa/TigoPesa/Airtel)
                      </Label>
                      <Input
                        id="paymentPhone"
                        type="tel"
                        value={paymentPhone}
                        onChange={(e) => setPaymentPhone(e.target.value)}
                        placeholder="0712345678"
                        required={!usePhoneForPayment}
                      />
                    </div>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full text-lg py-6"
                  style={{ backgroundColor: brandColor }}
                >
                  Lipa TZS {product.price.toLocaleString()}
                </Button>

                <p className="text-xs text-center text-muted-foreground">
                  Utapata USSD prompt kwenye simu yako kumaliza malipo
                </p>
              </form>
            </CardContent>
          </Card>
        )}

        {paymentStep === "processing" && (
          <Card>
            <CardContent className="py-12 text-center">
              <Loader2 className="h-16 w-16 mx-auto animate-spin text-primary mb-4" />
              <h2 className="text-xl font-bold mb-2">Inasubiri...</h2>
              <p className="text-muted-foreground">{paymentMessage}</p>
            </CardContent>
          </Card>
        )}

        {paymentStep === "success" && (
          <Card className="border-green-500">
            <CardContent className="py-12 text-center">
              <CheckCircle2 className="h-16 w-16 mx-auto text-green-500 mb-4" />
              <h2 className="text-xl font-bold mb-2">Ombi Limetumwa!</h2>
              <p className="text-muted-foreground mb-4">{paymentMessage}</p>
              {orderKey && (
                <p className="text-sm bg-muted p-3 rounded-lg">
                  Namba ya Agizo: <strong>{orderKey}</strong>
                </p>
              )}
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => setPaymentStep("form")}
              >
                Nunua Tena
              </Button>
            </CardContent>
          </Card>
        )}

        {paymentStep === "error" && (
          <Card className="border-red-500">
            <CardContent className="py-12 text-center">
              <AlertCircle className="h-16 w-16 mx-auto text-red-500 mb-4" />
              <h2 className="text-xl font-bold mb-2">Kosa Limetokea</h2>
              <p className="text-muted-foreground mb-4">{paymentMessage}</p>
              <Button
                variant="outline"
                onClick={() => setPaymentStep("form")}
              >
                Jaribu Tena
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Footer */}
      <div className="text-center py-8 text-sm text-muted-foreground">
        Powered by <Link href="/" className="text-primary hover:underline font-medium">LipaOnline</Link>
      </div>
    </div>
  )
}
