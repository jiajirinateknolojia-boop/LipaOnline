"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Store, Package, MapPin } from "lucide-react"

interface Product {
  id: string
  name: string
  price: number
  image_url: string | null
  slug: string
  is_active: boolean
}

interface MerchantData {
  id: string
  shop_name: string
  full_name: string
  region: string | null
  is_verified: boolean
  custom_branding: boolean
  branding_logo_url: string | null
  branding_color: string | null
  products: Product[]
}

export default function ShopPage() {
  const params = useParams()
  const shopName = params.shopName as string
  const [merchant, setMerchant] = useState<MerchantData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    async function fetchShop() {
      try {
        const res = await fetch(`/api/shop/${shopName}`)
        const data = await res.json()
        if (!res.ok) throw new Error(data.error)
        setMerchant(data)
      } catch (err: unknown) {
        setError(err instanceof Error ? err.message : "Duka halipatikani")
      } finally {
        setLoading(false)
      }
    }
    fetchShop()
  }, [shopName])

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-32 w-full mb-6" />
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-48 w-full" />
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (error || !merchant) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6 text-center">
            <Store className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h1 className="text-xl font-bold mb-2">Duka Halipatikani</h1>
            <p className="text-muted-foreground mb-4">{error || "Duka hili halipo au limefungwa"}</p>
            <Link href="/" className="text-primary hover:underline">
              Rudi Nyumbani
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const brandColor = merchant.custom_branding && merchant.branding_color ? merchant.branding_color : "#10b981"

  return (
    <div className="min-h-screen bg-background">
      {/* Shop Header */}
      <div 
        className="py-8 px-6"
        style={{ backgroundColor: brandColor }}
      >
        <div className="max-w-4xl mx-auto flex items-center gap-4">
          {merchant.branding_logo_url ? (
            <Image
              src={merchant.branding_logo_url}
              alt={merchant.shop_name}
              width={80}
              height={80}
              className="rounded-full bg-white p-1"
            />
          ) : (
            <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center">
              <Store className="h-10 w-10 text-white" />
            </div>
          )}
          <div className="text-white">
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">{merchant.shop_name}</h1>
              {merchant.is_verified && (
                <Badge variant="secondary" className="bg-white/20 text-white">
                  Imethibitishwa
                </Badge>
              )}
            </div>
            <p className="opacity-90">{merchant.full_name}</p>
            {merchant.region && (
              <div className="flex items-center gap-1 opacity-80 text-sm mt-1">
                <MapPin className="h-4 w-4" />
                {merchant.region}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Products */}
      <div className="max-w-4xl mx-auto p-6">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Package className="h-5 w-5" />
          Bidhaa ({merchant.products.length})
        </h2>

        {merchant.products.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Hakuna bidhaa bado</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {merchant.products.map((product) => (
              <Link
                key={product.id}
                href={`/shop/${shopName}/${product.slug}`}
              >
                <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer h-full">
                  <div className="aspect-square relative bg-muted">
                    {product.image_url ? (
                      <Image
                        src={product.image_url}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Package className="h-12 w-12 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <CardContent className="p-3">
                    <h3 className="font-medium line-clamp-2 text-sm">{product.name}</h3>
                    <p 
                      className="font-bold mt-1"
                      style={{ color: brandColor }}
                    >
                      TZS {product.price.toLocaleString()}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="text-center py-8 text-sm text-muted-foreground">
        Powered by <Link href="/" className="text-primary hover:underline font-medium">LipaOnline</Link>
      </div>
    </div>
  )
}
