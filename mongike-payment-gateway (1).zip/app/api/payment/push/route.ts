import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { pushPayment, generateOrderKey, formatPhoneNumber, detectProvider, calculatePlatformFee, calculateReferralCommission } from '@/lib/mongike'

export async function POST(request: NextRequest) {
  try {
    const { 
      product_id, 
      buyer_name, 
      buyer_phone, 
      buyer_location, 
      payment_phone 
    } = await request.json()
    
    if (!product_id || !buyer_name || !buyer_phone || !payment_phone) {
      return NextResponse.json(
        { error: 'Taarifa zote zinahitajika' },
        { status: 400 }
      )
    }
    
    const supabase = await createClient()
    
    // Get product details
    const { data: product, error: productError } = await supabase
      .from('products')
      .select('*, merchant:merchants(*)')
      .eq('id', product_id)
      .eq('is_active', true)
      .single()
    
    if (productError || !product) {
      return NextResponse.json(
        { error: 'Bidhaa haipatikani' },
        { status: 404 }
      )
    }
    
    // Check stock
    if (product.stock_quantity !== -1 && product.stock_quantity < 1) {
      return NextResponse.json(
        { error: 'Bidhaa imeisha stokini' },
        { status: 400 }
      )
    }
    
    // Generate order key
    const orderKey = generateOrderKey()
    const formattedPaymentPhone = formatPhoneNumber(payment_phone)
    const provider = detectProvider(payment_phone)
    
    // Create order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        order_key: orderKey,
        product_id: product.id,
        merchant_id: product.merchant_id,
        buyer_name,
        buyer_phone: formatPhoneNumber(buyer_phone),
        buyer_location,
        amount: product.price,
        status: 'pending',
        payment_phone: formattedPaymentPhone,
        payment_provider: provider,
      })
      .select()
      .single()
    
    if (orderError || !order) {
      console.error('Order creation error:', orderError)
      return NextResponse.json(
        { error: 'Imeshindwa kuunda agizo' },
        { status: 500 }
      )
    }
    
    // Get callback URL
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || request.nextUrl.origin
    const callbackUrl = `${baseUrl}/api/payment/callback`
    
    // Push payment request
    const paymentResult = await pushPayment({
      phone: formattedPaymentPhone,
      amount: product.price,
      reference: orderKey,
      callback_url: callbackUrl,
    })
    
    // Log payment request
    await supabase.from('payment_logs').insert({
      order_id: order.id,
      type: 'push_request',
      request_data: {
        phone: formattedPaymentPhone,
        amount: product.price,
        reference: orderKey,
      },
      response_data: paymentResult,
      status: paymentResult.success ? 'sent' : 'failed',
    })
    
    if (!paymentResult.success) {
      // Update order status to failed
      await supabase
        .from('orders')
        .update({ status: 'failed' })
        .eq('id', order.id)
      
      return NextResponse.json(
        { 
          error: paymentResult.message || 'Imeshindwa kutuma ombi la malipo',
          order_key: orderKey,
        },
        { status: 400 }
      )
    }
    
    // Update order with payment reference
    await supabase
      .from('orders')
      .update({ 
        status: 'processing',
        payment_reference: paymentResult.transaction_id,
      })
      .eq('id', order.id)
    
    return NextResponse.json({
      success: true,
      message: 'Ombi la malipo limetumwa. Angalia simu yako kwa USSD prompt.',
      order_key: orderKey,
      transaction_id: paymentResult.transaction_id,
    })
  } catch (error) {
    console.error('Payment push error:', error)
    return NextResponse.json(
      { error: 'Tatizo la seva, jaribu tena' },
      { status: 500 }
    )
  }
}
