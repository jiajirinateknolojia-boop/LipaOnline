import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { calculatePlatformFee, calculateReferralCommission } from '@/lib/mongike'

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    
    // Log callback
    console.log('Payment callback received:', data)
    
    const { reference, status, transaction_id, amount, phone, provider } = data
    
    if (!reference) {
      return NextResponse.json({ error: 'Reference required' }, { status: 400 })
    }
    
    const supabase = await createClient()
    
    // Get order by reference (order_key)
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('*, merchant:merchants(*), product:products(*)')
      .eq('order_key', reference)
      .single()
    
    if (orderError || !order) {
      console.error('Order not found for reference:', reference)
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }
    
    // Log callback
    await supabase.from('payment_logs').insert({
      order_id: order.id,
      type: 'callback',
      request_data: data,
      status: status,
    })
    
    // Already processed
    if (order.status === 'completed' || order.status === 'failed') {
      return NextResponse.json({ message: 'Order already processed' })
    }
    
    if (status === 'success') {
      // Payment successful
      const platformFee = calculatePlatformFee(order.amount)
      const netAmount = order.amount - platformFee
      
      // Update order status
      await supabase
        .from('orders')
        .update({
          status: 'completed',
          payment_reference: transaction_id,
          payment_provider: provider,
          updated_at: new Date().toISOString(),
        })
        .eq('id', order.id)
      
      // Update product sold count and stock
      await supabase
        .from('products')
        .update({
          total_sold: order.product.total_sold + 1,
          stock_quantity: order.product.stock_quantity === -1 
            ? -1 
            : order.product.stock_quantity - 1,
        })
        .eq('id', order.product_id)
      
      // Update merchant stats
      await supabase
        .from('merchants')
        .update({
          wallet_balance: order.merchant.wallet_balance + netAmount,
          total_sales: order.merchant.total_sales + order.amount,
          total_transactions: order.merchant.total_transactions + 1,
        })
        .eq('id', order.merchant_id)
      
      // Create sale transaction
      await supabase.from('transactions').insert({
        order_id: order.id,
        merchant_id: order.merchant_id,
        type: 'sale',
        amount: order.amount,
        fee_amount: platformFee,
        net_amount: netAmount,
        status: 'completed',
        payment_reference: transaction_id,
        description: `Sale: ${order.product.name}`,
      })
      
      // Handle referral commission if merchant was referred
      if (order.merchant.referred_by) {
        const referralCommission = calculateReferralCommission(order.amount)
        
        // Get referral record
        const { data: referral } = await supabase
          .from('referrals')
          .select('*')
          .eq('referred_id', order.merchant_id)
          .single()
        
        if (referral) {
          // Update referrer's wallet
          const { data: referrer } = await supabase
            .from('merchants')
            .select('wallet_balance')
            .eq('id', referral.referrer_id)
            .single()
          
          if (referrer) {
            await supabase
              .from('merchants')
              .update({
                wallet_balance: referrer.wallet_balance + referralCommission,
              })
              .eq('id', referral.referrer_id)
            
            // Update referral total earned
            await supabase
              .from('referrals')
              .update({
                total_earned: referral.total_earned + referralCommission,
              })
              .eq('id', referral.id)
            
            // Create referral transaction
            const { data: refTx } = await supabase.from('transactions').insert({
              merchant_id: referral.referrer_id,
              type: 'referral_commission',
              amount: referralCommission,
              fee_amount: 0,
              net_amount: referralCommission,
              status: 'completed',
              description: `Referral commission from ${order.merchant.shop_name}`,
            }).select().single()
            
            // Create referral earning record
            if (refTx) {
              await supabase.from('referral_earnings').insert({
                referral_id: referral.id,
                transaction_id: refTx.id,
                amount: referralCommission,
              })
            }
          }
        }
      }
      
      return NextResponse.json({ 
        success: true, 
        message: 'Payment processed successfully' 
      })
    } else if (status === 'failed') {
      // Payment failed
      await supabase
        .from('orders')
        .update({
          status: 'failed',
          updated_at: new Date().toISOString(),
        })
        .eq('id', order.id)
      
      return NextResponse.json({ 
        success: true, 
        message: 'Payment failure recorded' 
      })
    }
    
    return NextResponse.json({ message: 'Callback received' })
  } catch (error) {
    console.error('Payment callback error:', error)
    return NextResponse.json(
      { error: 'Callback processing failed' },
      { status: 500 }
    )
  }
}

// Also accept GET for status checks
export async function GET(request: NextRequest) {
  const reference = request.nextUrl.searchParams.get('reference')
  
  if (!reference) {
    return NextResponse.json({ error: 'Reference required' }, { status: 400 })
  }
  
  const supabase = await createClient()
  
  const { data: order, error } = await supabase
    .from('orders')
    .select('id, order_key, status, amount, created_at')
    .eq('order_key', reference)
    .single()
  
  if (error || !order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  }
  
  return NextResponse.json({ order })
}
