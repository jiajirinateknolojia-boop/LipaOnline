import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ shopName: string; productSlug: string }> }
) {
  try {
    const { shopName, productSlug } = await params
    
    const supabase = await createClient()
    
    // Get merchant by shop name
    const { data: merchant, error: merchantError } = await supabase
      .from('merchants')
      .select('id, shop_name, full_name, phone, region, custom_branding, branding_logo_url, branding_color')
      .eq('shop_name', decodeURIComponent(shopName))
      .eq('is_active', true)
      .single()
    
    if (merchantError || !merchant) {
      return NextResponse.json(
        { error: 'Duka halipatikani' },
        { status: 404 }
      )
    }
    
    // Get product by slug
    const { data: product, error: productError } = await supabase
      .from('products')
      .select('*')
      .eq('merchant_id', merchant.id)
      .eq('slug', decodeURIComponent(productSlug))
      .eq('is_active', true)
      .single()
    
    if (productError || !product) {
      return NextResponse.json(
        { error: 'Bidhaa haipatikani' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({
      merchant,
      product,
    })
  } catch (error) {
    console.error('Product fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch product' },
      { status: 500 }
    )
  }
}
