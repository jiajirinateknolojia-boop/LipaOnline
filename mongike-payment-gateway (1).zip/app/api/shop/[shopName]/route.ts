import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ shopName: string }> }
) {
  try {
    const { shopName } = await params
    
    const supabase = await createClient()
    
    // Get merchant by shop name
    const { data: merchant, error: merchantError } = await supabase
      .from('merchants')
      .select('id, shop_name, full_name, region, custom_branding, branding_logo_url, branding_color')
      .eq('shop_name', decodeURIComponent(shopName))
      .eq('is_active', true)
      .single()
    
    if (merchantError || !merchant) {
      return NextResponse.json(
        { error: 'Duka halipatikani' },
        { status: 404 }
      )
    }
    
    // Get products
    const { data: products, error: productsError } = await supabase
      .from('products')
      .select('id, name, description, price, image_url, product_type, slug, stock_quantity')
      .eq('merchant_id', merchant.id)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
    
    if (productsError) {
      return NextResponse.json({ error: productsError.message }, { status: 500 })
    }
    
    return NextResponse.json({
      merchant,
      products: products || [],
    })
  } catch (error) {
    console.error('Shop fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch shop' },
      { status: 500 }
    )
  }
}
