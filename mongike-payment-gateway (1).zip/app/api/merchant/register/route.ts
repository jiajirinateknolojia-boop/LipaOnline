import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

function generateReferralCode(shopName: string): string {
  const prefix = shopName.substring(0, 3).toUpperCase().replace(/[^A-Z]/g, 'X')
  const random = Math.random().toString(36).substring(2, 6).toUpperCase()
  return `${prefix}${random}`
}

export async function POST(request: NextRequest) {
  try {
    const { 
      shop_name, 
      phone, 
      email, 
      full_name, 
      region, 
      password,
      referral_code 
    } = await request.json()
    
    if (!shop_name || !phone || !full_name || !password) {
      return NextResponse.json(
        { error: 'Taarifa zote zinahitajika' },
        { status: 400 }
      )
    }
    
    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password lazima iwe na angalau herufi 6' },
        { status: 400 }
      )
    }
    
    const supabase = await createClient()
    
    // Check if shop name already exists
    const { data: existingShop } = await supabase
      .from('merchants')
      .select('id')
      .eq('shop_name', shop_name)
      .single()
    
    if (existingShop) {
      return NextResponse.json(
        { error: 'Jina la duka tayari linatumika' },
        { status: 400 }
      )
    }
    
    // Create auth user
    const signUpEmail = email || `${phone.replace(/[^0-9]/g, '')}@lipaonline.local`
    
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: signUpEmail,
      password,
      options: {
        data: {
          full_name,
          phone,
          role: 'merchant',
        },
      },
    })
    
    if (authError || !authData.user) {
      console.error('Auth signup error:', authError)
      return NextResponse.json(
        { error: authError?.message || 'Imeshindwa kuunda akaunti' },
        { status: 400 }
      )
    }
    
    // Check if referred by someone
    let referredBy: string | null = null
    if (referral_code) {
      const { data: referrer } = await supabase
        .from('merchants')
        .select('id')
        .eq('referral_code', referral_code.toUpperCase())
        .single()
      
      if (referrer) {
        referredBy = referrer.id
      }
    }
    
    // Create merchant profile
    const { data: merchant, error: merchantError } = await supabase
      .from('merchants')
      .insert({
        user_id: authData.user.id,
        shop_name,
        phone,
        email: email || null,
        full_name,
        region,
        referral_code: generateReferralCode(shop_name),
        referred_by: referredBy,
      })
      .select()
      .single()
    
    if (merchantError || !merchant) {
      console.error('Merchant creation error:', merchantError)
      // Cleanup auth user if merchant creation fails
      await supabase.auth.admin.deleteUser(authData.user.id)
      return NextResponse.json(
        { error: 'Imeshindwa kuunda duka' },
        { status: 500 }
      )
    }
    
    // Create referral record if referred
    if (referredBy) {
      await supabase.from('referrals').insert({
        referrer_id: referredBy,
        referred_id: merchant.id,
      })
    }
    
    return NextResponse.json({
      success: true,
      message: 'Duka limeundwa kikamilifu!',
      merchant: {
        id: merchant.id,
        shop_name: merchant.shop_name,
        referral_code: merchant.referral_code,
      },
    })
  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'Tatizo la seva, jaribu tena' },
      { status: 500 }
    )
  }
}
