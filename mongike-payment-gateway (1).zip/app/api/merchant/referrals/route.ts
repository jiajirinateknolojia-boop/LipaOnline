import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = await createClient()
    
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get merchant
    const { data: merchant } = await supabase
      .from("merchants")
      .select("id, referral_code")
      .eq("user_id", user.id)
      .single()

    if (!merchant) {
      return NextResponse.json({ error: "Merchant not found" }, { status: 404 })
    }

    // Get referrals (people this merchant referred)
    const { data: referrals } = await supabase
      .from("referrals")
      .select(`
        id,
        total_earned,
        created_at,
        referred:merchants!referrals_referred_id_fkey (
          id,
          shop_name,
          full_name,
          total_sales
        )
      `)
      .eq("referrer_id", merchant.id)
      .order("created_at", { ascending: false })

    // Calculate total earnings
    const totalEarnings = referrals?.reduce((sum, r) => sum + Number(r.total_earned), 0) || 0
    const totalReferrals = referrals?.length || 0

    return NextResponse.json({
      referralCode: merchant.referral_code,
      referralLink: `${process.env.NEXT_PUBLIC_APP_URL || ''}/register?ref=${merchant.referral_code}`,
      totalReferrals,
      totalEarnings,
      referrals: referrals || []
    })
  } catch (error) {
    console.error("Error fetching referrals:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
