import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET() {
  try {
    const supabase = await createClient()
    
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    // Get merchant
    const { data: merchant } = await supabase
      .from('merchants')
      .select('*')
      .eq('user_id', user.id)
      .single()
    
    if (!merchant) {
      return NextResponse.json({ error: 'Merchant not found' }, { status: 404 })
    }
    
    // Get products count
    const { count: totalProducts } = await supabase
      .from('products')
      .select('*', { count: 'exact', head: true })
      .eq('merchant_id', merchant.id)
    
    // Get orders
    const { count: totalOrders } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('merchant_id', merchant.id)
    
    const { count: completedOrders } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('merchant_id', merchant.id)
      .eq('status', 'completed')
    
    const { count: pendingOrders } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('merchant_id', merchant.id)
      .in('status', ['pending', 'processing'])
    
    // Get total withdrawn
    const { data: withdrawals } = await supabase
      .from('withdrawals')
      .select('net_amount')
      .eq('merchant_id', merchant.id)
      .eq('status', 'completed')
    
    const totalWithdrawn = withdrawals?.reduce((sum, w) => sum + Number(w.net_amount), 0) || 0
    
    // Get referral earnings
    const { data: referralData } = await supabase
      .from('referrals')
      .select('total_earned')
      .eq('referrer_id', merchant.id)
    
    const referralEarnings = referralData?.reduce((sum, r) => sum + Number(r.total_earned), 0) || 0
    
    return NextResponse.json({
      totalProducts: totalProducts || 0,
      totalOrders: totalOrders || 0,
      completedOrders: completedOrders || 0,
      pendingOrders: pendingOrders || 0,
      totalSales: merchant.total_sales,
      walletBalance: merchant.wallet_balance,
      totalWithdrawn,
      referralEarnings,
    })
  } catch (error) {
    console.error('Stats error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    )
  }
}
