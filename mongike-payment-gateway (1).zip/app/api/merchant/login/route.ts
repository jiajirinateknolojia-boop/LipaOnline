import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const { phone, password } = await request.json()
    
    if (!phone || !password) {
      return NextResponse.json(
        { error: 'Phone na password zinahitajika' },
        { status: 400 }
      )
    }
    
    const supabase = await createClient()
    
    // Find merchant by phone
    const { data: merchant, error: merchantError } = await supabase
      .from('merchants')
      .select('*, user:auth.users(email)')
      .eq('phone', phone)
      .single()
    
    if (merchantError || !merchant) {
      // Try with cleaned phone number
      const cleanedPhone = phone.replace(/[^0-9]/g, '')
      const { data: merchantByClean } = await supabase
        .from('merchants')
        .select('*')
        .or(`phone.eq.${cleanedPhone},phone.eq.255${cleanedPhone},phone.eq.0${cleanedPhone}`)
        .single()
      
      if (!merchantByClean) {
        return NextResponse.json(
          { error: 'Namba ya simu au password si sahihi' },
          { status: 401 }
        )
      }
    }
    
    // Get email for auth
    const email = merchant?.email || `${phone.replace(/[^0-9]/g, '')}@lipaonline.local`
    
    // Sign in with Supabase auth
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    })
    
    if (authError || !authData.user) {
      return NextResponse.json(
        { error: 'Namba ya simu au password si sahihi' },
        { status: 401 }
      )
    }
    
    // Get merchant details
    const { data: merchantData } = await supabase
      .from('merchants')
      .select('*')
      .eq('user_id', authData.user.id)
      .single()
    
    if (!merchantData) {
      return NextResponse.json(
        { error: 'Akaunti ya mfanyabiashara haipatikani' },
        { status: 404 }
      )
    }
    
    if (!merchantData.is_active) {
      return NextResponse.json(
        { error: 'Akaunti yako imezuiwa. Wasiliana na msaada.' },
        { status: 403 }
      )
    }
    
    return NextResponse.json({
      success: true,
      merchant: merchantData,
      session: authData.session,
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { error: 'Tatizo la seva, jaribu tena' },
      { status: 500 }
    )
  }
}
