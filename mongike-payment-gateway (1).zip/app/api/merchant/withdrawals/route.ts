import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { getWithdrawalFee } from '@/lib/mongike'

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    // Get merchant
    const { data: merchant } = await supabase
      .from('merchants')
      .select('id')
      .eq('user_id', user.id)
      .single()
    
    if (!merchant) {
      return NextResponse.json({ error: 'Merchant not found' }, { status: 404 })
    }
    
    const searchParams = request.nextUrl.searchParams
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = (page - 1) * limit
    
    const { data: withdrawals, count, error } = await supabase
      .from('withdrawals')
      .select('*', { count: 'exact' })
      .eq('merchant_id', merchant.id)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }
    
    return NextResponse.json({
      withdrawals: withdrawals || [],
      total: count || 0,
      page,
      limit,
    })
  } catch (error) {
    console.error('Withdrawals fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch withdrawals' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    // Get merchant
    const { data: merchant } = await supabase
      .from('merchants')
      .select('*')
      .eq('user_id', user.id)
      .single()
    
    if (!merchant) {
      return NextResponse.json({ error: 'Merchant not found' }, { status: 404 })
    }
    
    const { amount, phone } = await request.json()
    
    if (!amount || !phone) {
      return NextResponse.json(
        { error: 'Kiasi na namba ya simu vinahitajika' },
        { status: 400 }
      )
    }
    
    if (amount < 1000) {
      return NextResponse.json(
        { error: 'Kiasi cha chini ni TZS 1,000' },
        { status: 400 }
      )
    }
    
    if (amount > merchant.wallet_balance) {
      return NextResponse.json(
        { error: 'Salio haitoshi' },
        { status: 400 }
      )
    }
    
    // Get withdrawal tiers from settings
    const { data: tiersSetting } = await supabase
      .from('system_settings')
      .select('value')
      .eq('key', 'withdrawal_tiers')
      .single()
    
    const tiers = tiersSetting?.value || [
      { max: 100000, fee: 3000 },
      { max: 200000, fee: 5000 },
      { max: 300000, fee: 7000 },
      { max: 400000, fee: 9000 },
      { max: 500000, fee: 11000 },
    ]
    
    const fee = getWithdrawalFee(amount, tiers as { max: number; fee: number }[])
    const netAmount = amount - fee
    
    // Check for pending withdrawals
    const { count: pendingCount } = await supabase
      .from('withdrawals')
      .select('*', { count: 'exact', head: true })
      .eq('merchant_id', merchant.id)
      .eq('status', 'pending')
    
    if (pendingCount && pendingCount > 0) {
      return NextResponse.json(
        { error: 'Una ombi la kutoa pesa linalosubiri. Subiri likamilike kwanza.' },
        { status: 400 }
      )
    }
    
    // Create withdrawal request
    const { data: withdrawal, error } = await supabase
      .from('withdrawals')
      .insert({
        merchant_id: merchant.id,
        amount,
        fee,
        net_amount: netAmount,
        phone,
        status: 'pending',
      })
      .select()
      .single()
    
    if (error) {
      console.error('Withdrawal creation error:', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }
    
    return NextResponse.json({
      success: true,
      message: 'Ombi la kutoa pesa limewasilishwa',
      withdrawal,
    })
  } catch (error) {
    console.error('Withdrawal creation error:', error)
    return NextResponse.json(
      { error: 'Failed to create withdrawal' },
      { status: 500 }
    )
  }
}
