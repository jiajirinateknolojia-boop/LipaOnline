import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { createClient } from '@/lib/supabase/server'

export async function GET() {
  try {
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('admin_session')
    
    if (!sessionCookie) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const supabase = await createClient()
    
    // Get merchants count
    const { count: totalMerchants } = await supabase
      .from('merchants')
      .select('*', { count: 'exact', head: true })
    
    const { count: activeMerchants } = await supabase
      .from('merchants')
      .select('*', { count: 'exact', head: true })
      .eq('is_active', true)
    
    // Get products count
    const { count: totalProducts } = await supabase
      .from('products')
      .select('*', { count: 'exact', head: true })
    
    // Get orders
    const { count: totalOrders } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true })
    
    const { count: completedOrders } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'completed')
    
    // Get today's orders
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const { data: todayOrdersData } = await supabase
      .from('orders')
      .select('amount')
      .gte('created_at', today.toISOString())
      .eq('status', 'completed')
    
    const todayOrders = todayOrdersData?.length || 0
    const todayRevenue = todayOrdersData?.reduce((sum, o) => sum + Number(o.amount), 0) || 0
    
    // Get total revenue from completed orders
    const { data: revenueData } = await supabase
      .from('orders')
      .select('amount')
      .eq('status', 'completed')
    
    const totalRevenue = revenueData?.reduce((sum, o) => sum + Number(o.amount), 0) || 0
    const platformFees = Math.round(totalRevenue * 0.02)
    
    // Get pending withdrawals
    const { data: pendingWithdrawalsData } = await supabase
      .from('withdrawals')
      .select('amount')
      .eq('status', 'pending')
    
    const pendingWithdrawals = pendingWithdrawalsData?.reduce((sum, w) => sum + Number(w.amount), 0) || 0
    
    return NextResponse.json({
      totalMerchants: totalMerchants || 0,
      activeMerchants: activeMerchants || 0,
      totalProducts: totalProducts || 0,
      totalOrders: totalOrders || 0,
      completedOrders: completedOrders || 0,
      totalRevenue,
      platformFees,
      pendingWithdrawals,
      todayOrders,
      todayRevenue,
    })
  } catch (error) {
    console.error('Stats error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch stats' },
      { status: 500 }
    )
  }
}
