import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('admin_session')
    
    if (!sessionCookie) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const searchParams = request.nextUrl.searchParams
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const status = searchParams.get('status') || 'all'
    
    const offset = (page - 1) * limit
    
    const supabase = await createClient()
    
    let query = supabase
      .from('withdrawals')
      .select(`
        *,
        merchant:merchants(shop_name, phone, full_name)
      `, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)
    
    if (status !== 'all') {
      query = query.eq('status', status)
    }
    
    const { data, count, error } = await query
    
    if (error) {
      console.error('Withdrawals fetch error:', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }
    
    return NextResponse.json({
      withdrawals: data || [],
      total: count || 0,
      page,
      limit,
      totalPages: Math.ceil((count || 0) / limit),
    })
  } catch (error) {
    console.error('Withdrawals API error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch withdrawals' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('admin_session')
    
    if (!sessionCookie) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const session = JSON.parse(sessionCookie.value)
    const { id, status, admin_note } = await request.json()
    
    if (!id || !status) {
      return NextResponse.json({ error: 'ID and status required' }, { status: 400 })
    }
    
    const supabase = await createClient()
    
    // Get withdrawal details
    const { data: withdrawal, error: fetchError } = await supabase
      .from('withdrawals')
      .select('*, merchant:merchants(*)')
      .eq('id', id)
      .single()
    
    if (fetchError || !withdrawal) {
      return NextResponse.json({ error: 'Withdrawal not found' }, { status: 404 })
    }
    
    // Update withdrawal status
    const { data, error } = await supabase
      .from('withdrawals')
      .update({
        status,
        admin_note,
        processed_by: session.id,
        processed_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single()
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }
    
    // If completed, update merchant wallet balance
    if (status === 'completed') {
      await supabase
        .from('merchants')
        .update({
          wallet_balance: withdrawal.merchant.wallet_balance - withdrawal.amount,
        })
        .eq('id', withdrawal.merchant_id)
      
      // Create transaction record
      await supabase.from('transactions').insert({
        merchant_id: withdrawal.merchant_id,
        type: 'withdrawal',
        amount: withdrawal.amount,
        fee_amount: withdrawal.fee,
        net_amount: withdrawal.net_amount,
        status: 'completed',
        description: `Withdrawal to ${withdrawal.phone}`,
      })
    }
    
    return NextResponse.json({ withdrawal: data })
  } catch (error) {
    console.error('Withdrawal update error:', error)
    return NextResponse.json(
      { error: 'Failed to update withdrawal' },
      { status: 500 }
    )
  }
}
