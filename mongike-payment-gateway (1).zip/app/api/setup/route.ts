import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import bcrypt from 'bcryptjs'

// This route creates the default admin user using service role
// Only run once during setup
export async function GET() {
  try {
    // Use service role to bypass RLS
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    )
    
    // Hash the password
    const passwordHash = await bcrypt.hash('Lipa2030', 10)
    
    // Delete existing admin with same username to ensure clean state
    await supabase
      .from('admins')
      .delete()
      .eq('username', 'swabur')
    
    // Create admin
    const { data, error } = await supabase
      .from('admins')
      .insert({
        username: 'swabur',
        password_hash: passwordHash,
        full_name: 'Admin Swabur',
        is_super_admin: true,
      })
      .select()
      .single()
    
    if (error) {
      console.error('Admin creation error:', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }
    
    return NextResponse.json({ 
      success: true, 
      message: 'Admin created successfully',
      admin: data,
      credentials: {
        username: 'swabur',
        password: 'Lipa2030',
      }
    })
  } catch (error) {
    console.error('Setup error:', error)
    return NextResponse.json(
      { error: 'Setup failed' },
      { status: 500 }
    )
  }
}
