import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

import { 
  Smartphone, 
  Store, 
  CreditCard, 
  TrendingUp, 
  Users, 
  Shield, 
  ArrowRight,
  CheckCircle2,
  Globe,
  Zap
} from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <CreditCard className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">LipaOnline</span>
          </Link>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link href="/login">Ingia</Link>
            </Button>
            <Button asChild>
              <Link href="/register">Jiunge Sasa</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent" />
        <div className="max-w-6xl mx-auto px-6 py-20 md:py-32 relative">
          <div className="max-w-3xl">
            <p className="text-primary font-medium mb-4">Karibu LIPA ONLINE</p>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 text-balance">
              Uza Bidhaa Zako Online na Pokea Malipo Haraka
            </h1>
            <p className="text-xl text-muted-foreground mb-8 text-pretty">
              LipaOnline inakuwezesha kuunda duka lako la online na kupokea malipo kupitia 
              M-Pesa, TigoPesa, na Airtel Money. Bila gharama ya kuanza!
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="text-lg px-8" asChild>
                <Link href="/register">
                  Anza Kuuza Leo
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Kwa Nini LipaOnline?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Tumetengeneza jukwaa rahisi na lenye nguvu kwa wafanyabiashara wa Tanzania
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="border-2 hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Smartphone className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Malipo ya Mobile Money</CardTitle>
                <CardDescription>
                  Pokea malipo kupitia M-Pesa, TigoPesa, na Airtel Money kwa urahisi
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Push Payment - Mteja anapata USSD
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Malipo yanaingia moja kwa moja
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Ada ndogo tu 2%
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Store className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Duka Lako Online</CardTitle>
                <CardDescription>
                  Pata link maalum ya bidhaa yako unayoweza kushare WhatsApp, Facebook
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Link moja kwa kila bidhaa
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Mteja anunue moja kwa moja
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Picha, maelezo, bei
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Dashboard ya Biashara</CardTitle>
                <CardDescription>
                  Fuatilia mauzo, wateja, na pesa zako kwa urahisi
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Ripoti za mauzo
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Toa pesa wakati wowote
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    Historia ya miamala
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Bei Rahisi na Wazi</h2>
            <p className="text-muted-foreground">
              Hakuna gharama ya kuanza - lipa tu unapomaliza mauzo
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle>Ada ya Muamala</CardTitle>
                <div className="text-4xl font-bold text-primary">2%</div>
                <CardDescription>Kwa kila mauzo yaliyofanikiwa</CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Kutoa Pesa</CardTitle>
                <div className="text-4xl font-bold text-primary">TZS 3,000</div>
                <CardDescription>Kuanzia, kulingana na kiasi</CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Custom Branding</CardTitle>
                <div className="text-4xl font-bold text-primary">TZS 1,000</div>
                <CardDescription>Kwa mwezi - logo na rangi</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Referral Section */}
      <section className="py-20 bg-primary/5">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                <Users className="h-3 w-3" />
                Mfumo wa Kualikana
              </div>
              <h2 className="text-3xl font-bold mb-4">Alika na Upate 0.5%</h2>
              <p className="text-muted-foreground mb-6">
                Kwa kila mfanyabiashara unayemwalika, utapata 0.5% ya mauzo yake yote 
                kwa muda wote. Kadri unavyoalika wengi, ndivyo unavyopata zaidi!
              </p>
              <ul className="space-y-3">
                <li className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="font-bold text-primary">1</span>
                  </div>
                  <span>Pata link yako ya kualika</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="font-bold text-primary">2</span>
                  </div>
                  <span>Share kwa marafiki wafanyabiashara</span>
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="font-bold text-primary">3</span>
                  </div>
                  <span>Pata commission ya kila mauzo yao</span>
                </li>
              </ul>
            </div>
            <div className="relative">
              <Card className="p-8 bg-card">
                <div className="flex items-center justify-between mb-6">
                  <div className="text-sm text-muted-foreground">Jumla ya Commission</div>
                  <span className="px-2 py-1 rounded bg-muted text-muted-foreground text-xs">Mfano</span>
                </div>
                <div className="text-5xl font-bold text-primary mb-2">TZS 125,000</div>
                <div className="text-muted-foreground">Kutoka kwa wafanyabiashara 10</div>
                <div className="mt-6 pt-6 border-t">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Jumla ya mauzo yao</span>
                    <span className="font-medium">TZS 25,000,000</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-bold mb-2">Salama na Imara</h3>
              <p className="text-sm text-muted-foreground">
                Malipo yako yamelindwa na mfumo wa kisasa wa usalama
              </p>
            </div>
            <div>
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Globe className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-bold mb-2">Tanzania Nzima</h3>
              <p className="text-sm text-muted-foreground">
                Uza na upokee malipo kutoka kona yoyote ya Tanzania
              </p>
            </div>
            <div>
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Zap className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-bold mb-2">Haraka Sana</h3>
              <p className="text-sm text-muted-foreground">
                Anza kuuza ndani ya dakika 5 baada ya kusajili
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Tayari Kuanza Kuuza Online?
          </h2>
          <p className="text-lg opacity-90 mb-8">
            Jiunge na maelfu ya wafanyabiashara wanaotumia LipaOnline leo
          </p>
          <Button size="lg" variant="secondary" className="text-lg px-8" asChild>
            <Link href="/register">
              Fungua Duka Lako Bure
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <Link href="/" className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                  <CreditCard className="h-4 w-4 text-primary-foreground" />
                </div>
                <span className="font-bold">LipaOnline</span>
              </Link>
              <p className="text-sm text-muted-foreground">
                Jukwaa la kisasa la malipo na uuzaji online Tanzania
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Bidhaa</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/register" className="hover:text-foreground">Anza Kuuza</Link></li>
                <li><Link href="/login" className="hover:text-foreground">Ingia</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Msaada</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Maswali Yanayoulizwa</a></li>
                <li><a href="#" className="hover:text-foreground">Wasiliana Nasi</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Kisheria</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Masharti ya Huduma</a></li>
                <li><a href="#" className="hover:text-foreground">Sera ya Faragha</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-12 pt-8 text-center text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} LipaOnline. Haki zote zimehifadhiwa.
          </div>
        </div>
      </footer>
    </div>
  )
}
