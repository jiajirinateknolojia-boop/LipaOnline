'use client'

import { useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, Store, Gift } from 'lucide-react'

function RegisterForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const referralCode = searchParams.get('ref') || ''
  
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [formData, setFormData] = useState({
    shop_name: '',
    full_name: '',
    phone: '',
    email: '',
    region: '',
    password: '',
    confirmPassword: '',
    referral_code: referralCode,
  })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    if (formData.password !== formData.confirmPassword) {
      setError('Password hazifanani')
      setLoading(false)
      return
    }

    if (formData.password.length < 6) {
      setError('Password lazima iwe na angalau herufi 6')
      setLoading(false)
      return
    }

    try {
      const res = await fetch('/api/merchant/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shop_name: formData.shop_name,
          full_name: formData.full_name,
          phone: formData.phone,
          email: formData.email || undefined,
          region: formData.region || undefined,
          password: formData.password,
          referral_code: formData.referral_code || undefined,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.error || 'Imeshindwa kusajili')
      }

      // Redirect to login
      router.push('/login?registered=true')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Imeshindwa kusajili')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 to-muted p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="space-y-1 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <Store className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">Fungua Duka Lako</CardTitle>
          <CardDescription>
            Jisajili na uanze kuuza bidhaa zako mtandaoni
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {referralCode && (
              <Alert className="bg-green-50 border-green-200">
                <Gift className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  Umealikwa na mfanyabiashara mwenzako!
                </AlertDescription>
              </Alert>
            )}
            
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="shop_name">Jina la Duka *</Label>
                <Input
                  id="shop_name"
                  placeholder="Mfano: Duka la Ali"
                  value={formData.shop_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, shop_name: e.target.value }))}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="full_name">Jina Lako Kamili *</Label>
                <Input
                  id="full_name"
                  placeholder="Mfano: Ali Hassan"
                  value={formData.full_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, full_name: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="phone">Namba ya Simu *</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="0712345678"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email (Hiari)</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="ali@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="region">Mkoa (Hiari)</Label>
              <Input
                id="region"
                placeholder="Mfano: Dar es Salaam"
                value={formData.region}
                onChange={(e) => setFormData(prev => ({ ...prev, region: e.target.value }))}
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Angalau herufi 6"
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Thibitisha Password *</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Rudia password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="referral_code">Msimbo wa Mualiko (Hiari)</Label>
              <Input
                id="referral_code"
                placeholder="Mfano: ABC123"
                value={formData.referral_code}
                onChange={(e) => setFormData(prev => ({ ...prev, referral_code: e.target.value.toUpperCase() }))}
              />
            </div>
            
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Inasajili...
                </>
              ) : (
                'Jisajili Sasa'
              )}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col gap-4">
          <div className="text-center text-sm text-muted-foreground">
            Una akaunti tayari?{' '}
            <Link href="/login" className="text-primary hover:underline">
              Ingia hapa
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}

export default function RegisterPage() {
  return (
    <Suspense fallback={
      <div className="flex min-h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    }>
      <RegisterForm />
    </Suspense>
  )
}
