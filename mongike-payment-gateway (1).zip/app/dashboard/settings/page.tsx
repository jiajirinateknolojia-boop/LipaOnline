'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, Shield, Store, Copy, Check } from 'lucide-react'
import type { Merchant } from '@/lib/types'

export default function SettingsPage() {
  const [merchant, setMerchant] = useState<Merchant | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [copied, setCopied] = useState(false)
  const [formData, setFormData] = useState({
    full_name: '',
    region: '',
  })

  useEffect(() => {
    fetchProfile()
  }, [])

  async function fetchProfile() {
    try {
      const res = await fetch('/api/merchant/profile')
      const data = await res.json()
      setMerchant(data.merchant)
      setFormData({
        full_name: data.merchant?.full_name || '',
        region: data.merchant?.region || '',
      })
    } catch (error) {
      console.error('Failed to fetch profile:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    setError('')
    setSuccess('')

    try {
      const res = await fetch('/api/merchant/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })

      if (!res.ok) {
        throw new Error('Failed to update profile')
      }

      setSuccess('Taarifa zimesasishwa kikamilifu!')
      fetchProfile()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Imeshindwa kusasisha')
    } finally {
      setSaving(false)
    }
  }

  function copyShopLink() {
    if (merchant?.shop_name) {
      const link = `${window.location.origin}/s/${encodeURIComponent(merchant.shop_name)}`
      navigator.clipboard.writeText(link)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Mipangilio</h2>
        <p className="text-muted-foreground">
          Simamia taarifa za akaunti yako
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Taarifa za Duka</CardTitle>
            <CardDescription>
              Taarifa za msingi za duka lako
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4 rounded-lg border p-4">
              <Store className="h-10 w-10 text-muted-foreground" />
              <div className="flex-1">
                <p className="font-medium">{merchant?.shop_name}</p>
                <p className="text-sm text-muted-foreground">{merchant?.phone}</p>
              </div>
              <div className="flex flex-col gap-1">
                {merchant?.is_verified && (
                  <Badge className="gap-1">
                    <Shield className="h-3 w-3" />
                    Imethibitishwa
                  </Badge>
                )}
                <Badge variant="outline">{merchant?.subscription_type === 'free' ? 'Bure' : 'Premium'}</Badge>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Link ya Duka Lako</Label>
              <div className="flex gap-2">
                <Input
                  value={`${typeof window !== 'undefined' ? window.location.origin : ''}/s/${encodeURIComponent(merchant?.shop_name || '')}`}
                  readOnly
                  className="text-sm"
                />
                <Button variant="outline" onClick={copyShopLink}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Hariri Taarifa</CardTitle>
            <CardDescription>
              Sasisha taarifa zako za msingi
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              {success && (
                <Alert className="bg-green-50 border-green-200">
                  <AlertDescription className="text-green-800">{success}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="full_name">Jina Kamili</Label>
                <Input
                  id="full_name"
                  value={formData.full_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, full_name: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="region">Mkoa</Label>
                <Input
                  id="region"
                  placeholder="Mfano: Dar es Salaam"
                  value={formData.region}
                  onChange={(e) => setFormData(prev => ({ ...prev, region: e.target.value }))}
                />
              </div>

              <Button type="submit" disabled={saving}>
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Inahifadhi...
                  </>
                ) : (
                  'Hifadhi Mabadiliko'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
