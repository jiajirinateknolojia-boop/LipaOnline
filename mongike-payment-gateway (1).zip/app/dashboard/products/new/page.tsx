'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, ArrowLeft } from 'lucide-react'
import Link from 'next/link'

export default function NewProductPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    image_url: '',
    product_type: 'physical',
    digital_file_url: '',
    stock_quantity: '-1',
  })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/merchant/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          price: parseFloat(formData.price),
          stock_quantity: parseInt(formData.stock_quantity),
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.error || 'Failed to create product')
      }

      router.push('/dashboard/products')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create product')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/dashboard/products">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Ongeza Bidhaa</h2>
          <p className="text-muted-foreground">
            Jaza taarifa za bidhaa yako mpya
          </p>
        </div>
      </div>

      <Card className="max-w-2xl">
        <CardHeader>
          <CardTitle>Taarifa za Bidhaa</CardTitle>
          <CardDescription>
            Taarifa hizi zitaonyeshwa kwa wateja wako
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="name">Jina la Bidhaa *</Label>
              <Input
                id="name"
                placeholder="Mfano: Simu ya Mkono Samsung"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Maelezo</Label>
              <Textarea
                id="description"
                placeholder="Eleza bidhaa yako kwa ufupi..."
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={4}
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="price">Bei (TZS) *</Label>
                <Input
                  id="price"
                  type="number"
                  placeholder="50000"
                  min="100"
                  value={formData.price}
                  onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="product_type">Aina ya Bidhaa</Label>
                <Select
                  value={formData.product_type}
                  onValueChange={(v) => setFormData(prev => ({ ...prev, product_type: v }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="physical">Bidhaa ya Kawaida</SelectItem>
                    <SelectItem value="digital">Bidhaa ya Digital</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="image_url">URL ya Picha</Label>
              <Input
                id="image_url"
                type="url"
                placeholder="https://example.com/picha.jpg"
                value={formData.image_url}
                onChange={(e) => setFormData(prev => ({ ...prev, image_url: e.target.value }))}
              />
              <p className="text-xs text-muted-foreground">
                Weka link ya picha ya bidhaa yako (hiari)
              </p>
            </div>

            {formData.product_type === 'digital' && (
              <div className="space-y-2">
                <Label htmlFor="digital_file_url">URL ya Faili ya Digital</Label>
                <Input
                  id="digital_file_url"
                  type="url"
                  placeholder="https://example.com/faili.pdf"
                  value={formData.digital_file_url}
                  onChange={(e) => setFormData(prev => ({ ...prev, digital_file_url: e.target.value }))}
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="stock_quantity">Idadi ya Stoki</Label>
              <Input
                id="stock_quantity"
                type="number"
                placeholder="-1 = Bila kikomo"
                value={formData.stock_quantity}
                onChange={(e) => setFormData(prev => ({ ...prev, stock_quantity: e.target.value }))}
              />
              <p className="text-xs text-muted-foreground">
                Weka -1 kama huna kikomo cha stoki
              </p>
            </div>

            <div className="flex gap-4">
              <Button type="button" variant="outline" asChild>
                <Link href="/dashboard/products">Ghairi</Link>
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Inaunda...
                  </>
                ) : (
                  'Unda Bidhaa'
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
