'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Users, Copy, Gift, Check } from 'lucide-react'
import { formatCurrency } from '@/lib/mongike'
import type { Merchant } from '@/lib/types'

export default function ReferralsPage() {
  const [merchant, setMerchant] = useState<Merchant | null>(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    fetchProfile()
  }, [])

  async function fetchProfile() {
    try {
      const res = await fetch('/api/merchant/profile')
      const data = await res.json()
      setMerchant(data.merchant)
    } catch (error) {
      console.error('Failed to fetch profile:', error)
    } finally {
      setLoading(false)
    }
  }

  function copyReferralCode() {
    if (merchant?.referral_code) {
      navigator.clipboard.writeText(merchant.referral_code)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  function copyReferralLink() {
    if (merchant?.referral_code) {
      const link = `${window.location.origin}/register?ref=${merchant.referral_code}`
      navigator.clipboard.writeText(link)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Mfumo wa Mualiko</h2>
        <p className="text-muted-foreground">
          Alika wafanyabiashara wenzako na upate commission
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="h-5 w-5 text-primary" />
              Jinsi Inavyofanya Kazi
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold">
                1
              </div>
              <div>
                <p className="font-medium">Shiriki Msimbo Wako</p>
                <p className="text-sm text-muted-foreground">
                  Tuma msimbo wako wa mualiko kwa marafiki na familia
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold">
                2
              </div>
              <div>
                <p className="font-medium">Wanajisajili</p>
                <p className="text-sm text-muted-foreground">
                  Wanapojisajili na msimbo wako, wanakuwa referral wako
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold">
                3
              </div>
              <div>
                <p className="font-medium">Pata Commission</p>
                <p className="text-sm text-muted-foreground">
                  Unapata 0.5% ya kila muamala wanaoufanya - milele!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              Msimbo Wako wa Mualiko
            </CardTitle>
            <CardDescription>
              Shiriki msimbo huu na wengine
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Msimbo</label>
              <div className="flex gap-2">
                <Input
                  value={merchant?.referral_code || ''}
                  readOnly
                  className="font-mono text-lg font-bold"
                />
                <Button variant="outline" onClick={copyReferralCode}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Link ya Kusajili</label>
              <div className="flex gap-2">
                <Input
                  value={`${typeof window !== 'undefined' ? window.location.origin : ''}/register?ref=${merchant?.referral_code || ''}`}
                  readOnly
                  className="text-sm"
                />
                <Button variant="outline" onClick={copyReferralLink}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Maelezo ya Commission</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg border p-4 text-center">
              <p className="text-4xl font-bold text-primary">0.5%</p>
              <p className="text-sm text-muted-foreground mt-1">Commission kwa kila muamala</p>
            </div>
            <div className="rounded-lg border p-4 text-center">
              <p className="text-4xl font-bold text-primary">Milele</p>
              <p className="text-sm text-muted-foreground mt-1">Unapata kwa muda wote</p>
            </div>
            <div className="rounded-lg border p-4 text-center">
              <p className="text-4xl font-bold text-primary">Bure</p>
              <p className="text-sm text-muted-foreground mt-1">Hakuna malipo ya kuanza</p>
            </div>
          </div>
          
          <div className="mt-6 rounded-lg bg-muted p-4">
            <p className="font-medium">Mfano:</p>
            <p className="text-sm text-muted-foreground mt-1">
              Ukimualika mtu na akafanya mauzo ya TZS 1,000,000, utapata TZS 5,000 kama commission. 
              Hii inaendelea kwa kila muamala anaoufanya!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
