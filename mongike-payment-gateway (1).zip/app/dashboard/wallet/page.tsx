'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Wallet, ArrowDownRight, Loader2 } from 'lucide-react'
import { formatCurrency, getWithdrawalFee } from '@/lib/mongike'
import { format } from 'date-fns'
import type { Withdrawal, MerchantStats } from '@/lib/types'

const withdrawalTiers = [
  { max: 100000, fee: 3000 },
  { max: 200000, fee: 5000 },
  { max: 300000, fee: 7000 },
  { max: 400000, fee: 9000 },
  { max: 500000, fee: 11000 },
]

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  approved: 'bg-blue-100 text-blue-800',
  processing: 'bg-purple-100 text-purple-800',
  completed: 'bg-green-100 text-green-800',
  rejected: 'bg-red-100 text-red-800',
}

const statusLabels: Record<string, string> = {
  pending: 'Inasubiri',
  approved: 'Imekubaliwa',
  processing: 'Inachakatwa',
  completed: 'Imekamilika',
  rejected: 'Imekataliwa',
}

export default function WalletPage() {
  const [stats, setStats] = useState<MerchantStats | null>(null)
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [formData, setFormData] = useState({
    amount: '',
    phone: '',
  })

  useEffect(() => {
    fetchData()
  }, [])

  async function fetchData() {
    try {
      const [statsRes, withdrawalsRes] = await Promise.all([
        fetch('/api/merchant/stats'),
        fetch('/api/merchant/withdrawals'),
      ])
      
      const statsData = await statsRes.json()
      const withdrawalsData = await withdrawalsRes.json()
      
      setStats(statsData)
      setWithdrawals(withdrawalsData.withdrawals || [])
    } catch (error) {
      console.error('Failed to fetch data:', error)
    } finally {
      setLoading(false)
    }
  }

  const amount = parseFloat(formData.amount) || 0
  const fee = getWithdrawalFee(amount, withdrawalTiers)
  const netAmount = Math.max(0, amount - fee)

  async function handleWithdraw(e: React.FormEvent) {
    e.preventDefault()
    setSubmitting(true)
    setError('')
    setSuccess('')

    try {
      const res = await fetch('/api/merchant/withdrawals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseFloat(formData.amount),
          phone: formData.phone,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.error || 'Imeshindwa kutoa ombi')
      }

      setSuccess('Ombi lako limewasilishwa kikamilifu!')
      setFormData({ amount: '', phone: '' })
      setDialogOpen(false)
      fetchData()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Imeshindwa kutoa ombi')
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Pochi</h2>
        <p className="text-muted-foreground">
          Simamia salio lako na maombi ya kutoa pesa
        </p>
      </div>

      {success && (
        <Alert className="bg-green-50 border-green-200">
          <AlertDescription className="text-green-800">{success}</AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="md:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Salio la Pochi
            </CardTitle>
            <Wallet className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">
              {formatCurrency(stats?.walletBalance || 0)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Kiasi kinachopatikana kwa kutoa
            </p>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="w-full mt-4">
                  <ArrowDownRight className="mr-2 h-4 w-4" />
                  Toa Pesa
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Toa Pesa</DialogTitle>
                  <DialogDescription>
                    Kiasi kitapatikana kwenye simu yako ndani ya dakika 24
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleWithdraw} className="space-y-4">
                  {error && (
                    <Alert variant="destructive">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="amount">Kiasi (TZS)</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="50000"
                      min="1000"
                      max={stats?.walletBalance || 0}
                      value={formData.amount}
                      onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                      required
                    />
                    <p className="text-xs text-muted-foreground">
                      Kiwango cha chini: TZS 1,000 | Salio: {formatCurrency(stats?.walletBalance || 0)}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Namba ya Simu</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="0712345678"
                      value={formData.phone}
                      onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                      required
                    />
                    <p className="text-xs text-muted-foreground">
                      Namba ya M-Pesa, TigoPesa, au Airtel Money
                    </p>
                  </div>

                  {amount > 0 && (
                    <div className="rounded-lg bg-muted p-4 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Kiasi:</span>
                        <span>{formatCurrency(amount)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Ada:</span>
                        <span>- {formatCurrency(fee)}</span>
                      </div>
                      <div className="border-t pt-2 flex justify-between font-medium">
                        <span>Utapata:</span>
                        <span className="text-primary">{formatCurrency(netAmount)}</span>
                      </div>
                    </div>
                  )}

                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                      Ghairi
                    </Button>
                    <Button type="submit" disabled={submitting || amount < 1000}>
                      {submitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Inatuma...
                        </>
                      ) : (
                        'Toa Pesa'
                      )}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Ada za Kutoa Pesa</CardTitle>
            <CardDescription>Ada kulingana na kiasi cha kutoa</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2 sm:grid-cols-5">
              {withdrawalTiers.map((tier, index) => {
                const minAmount = index === 0 ? 1000 : withdrawalTiers[index - 1].max + 1
                return (
                  <div key={tier.max} className="rounded-lg border p-3 text-center">
                    <p className="text-xs text-muted-foreground">
                      {formatCurrency(minAmount)} - {formatCurrency(tier.max)}
                    </p>
                    <p className="mt-1 text-lg font-bold">{formatCurrency(tier.fee)}</p>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Historia ya Kutoa Pesa</CardTitle>
        </CardHeader>
        <CardContent>
          {withdrawals.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Huna historia ya kutoa pesa
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tarehe</TableHead>
                    <TableHead>Kiasi</TableHead>
                    <TableHead>Ada</TableHead>
                    <TableHead>Ulipata</TableHead>
                    <TableHead>Simu</TableHead>
                    <TableHead>Hali</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {withdrawals.map((withdrawal) => (
                    <TableRow key={withdrawal.id}>
                      <TableCell className="text-sm text-muted-foreground">
                        {format(new Date(withdrawal.created_at), 'dd/MM/yyyy HH:mm')}
                      </TableCell>
                      <TableCell>{formatCurrency(withdrawal.amount)}</TableCell>
                      <TableCell>{formatCurrency(withdrawal.fee)}</TableCell>
                      <TableCell className="font-medium">{formatCurrency(withdrawal.net_amount)}</TableCell>
                      <TableCell>{withdrawal.phone}</TableCell>
                      <TableCell>
                        <Badge className={statusColors[withdrawal.status] || ''} variant="outline">
                          {statusLabels[withdrawal.status] || withdrawal.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
