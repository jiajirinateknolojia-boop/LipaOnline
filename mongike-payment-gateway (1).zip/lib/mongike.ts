// Mongike Payment Gateway Integration
// API Documentation: https://mongike.com/api/v1

const MONGIKE_API_URL = 'https://mongike.com/api/v1'
const MONGIKE_API_KEY = process.env.MONGIKE_API_KEY || ''

export interface PushPaymentRequest {
  phone: string
  amount: number
  reference: string
  callback_url?: string
}

export interface PushPaymentResponse {
  success: boolean
  message: string
  transaction_id?: string
  reference?: string
  error?: string
}

export interface PaymentStatusResponse {
  success: boolean
  status: 'pending' | 'success' | 'failed'
  transaction_id?: string
  reference?: string
  amount?: number
  phone?: string
  provider?: string
  message?: string
}

// Format phone number to Tanzania format (255...)
export function formatPhoneNumber(phone: string): string {
  // Remove spaces, dashes, and plus signs
  let cleaned = phone.replace(/[\s\-\+]/g, '')
  
  // If starts with 0, replace with 255
  if (cleaned.startsWith('0')) {
    cleaned = '255' + cleaned.substring(1)
  }
  
  // If doesn't start with 255, add it
  if (!cleaned.startsWith('255')) {
    cleaned = '255' + cleaned
  }
  
  return cleaned
}

// Detect mobile money provider from phone number
export function detectProvider(phone: string): 'mpesa' | 'tigopesa' | 'airtel' | 'halopesa' | 'unknown' {
  const formattedPhone = formatPhoneNumber(phone)
  const prefix = formattedPhone.substring(3, 5) // Get 2 digits after 255
  
  // M-Pesa prefixes (Vodacom)
  if (['74', '75', '76'].includes(prefix)) return 'mpesa'
  
  // Tigo Pesa prefixes
  if (['71', '65', '67'].includes(prefix)) return 'tigopesa'
  
  // Airtel Money prefixes
  if (['78', '68', '69'].includes(prefix)) return 'airtel'
  
  // Halotel prefixes
  if (['62'].includes(prefix)) return 'halopesa'
  
  return 'unknown'
}

// Push Payment - Customer receives USSD prompt on their phone
export async function pushPayment(request: PushPaymentRequest): Promise<PushPaymentResponse> {
  try {
    const formattedPhone = formatPhoneNumber(request.phone)
    
    const response = await fetch(`${MONGIKE_API_URL}/push`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${MONGIKE_API_KEY}`,
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        phone: formattedPhone,
        amount: Math.round(request.amount), // Amount in TZS
        reference: request.reference,
        callback_url: request.callback_url,
      }),
    })
    
    const data = await response.json()
    
    if (!response.ok) {
      return {
        success: false,
        message: data.message || 'Payment request failed',
        error: data.error,
      }
    }
    
    return {
      success: true,
      message: data.message || 'Payment request sent successfully',
      transaction_id: data.transaction_id,
      reference: data.reference || request.reference,
    }
  } catch (error) {
    console.error('Mongike Push Payment Error:', error)
    return {
      success: false,
      message: 'Failed to connect to payment gateway',
      error: error instanceof Error ? error.message : 'Unknown error',
    }
  }
}

// Check Payment Status
export async function checkPaymentStatus(reference: string): Promise<PaymentStatusResponse> {
  try {
    const response = await fetch(`${MONGIKE_API_URL}/status/${reference}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${MONGIKE_API_KEY}`,
        'Accept': 'application/json',
      },
    })
    
    const data = await response.json()
    
    if (!response.ok) {
      return {
        success: false,
        status: 'pending',
        message: data.message || 'Failed to check payment status',
      }
    }
    
    return {
      success: true,
      status: data.status || 'pending',
      transaction_id: data.transaction_id,
      reference: data.reference,
      amount: data.amount,
      phone: data.phone,
      provider: data.provider,
      message: data.message,
    }
  } catch (error) {
    console.error('Mongike Status Check Error:', error)
    return {
      success: false,
      status: 'pending',
      message: 'Failed to connect to payment gateway',
    }
  }
}

// Generate unique order reference
export function generateOrderKey(): string {
  const timestamp = Date.now().toString(36).toUpperCase()
  const random = Math.random().toString(36).substring(2, 8).toUpperCase()
  return `LP${timestamp}${random}`
}

// Format currency for display (TZS)
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('sw-TZ', {
    style: 'currency',
    currency: 'TZS',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

// Calculate platform fee (2%)
export function calculatePlatformFee(amount: number): number {
  return Math.round(amount * 0.02)
}

// Calculate referral commission (0.5%)
export function calculateReferralCommission(amount: number): number {
  return Math.round(amount * 0.005)
}

// Get withdrawal fee based on amount
export function getWithdrawalFee(amount: number, tiers: { max: number; fee: number }[]): number {
  // Sort tiers by max amount
  const sortedTiers = [...tiers].sort((a, b) => a.max - b.max)
  
  for (const tier of sortedTiers) {
    if (amount <= tier.max) {
      return tier.fee
    }
  }
  
  // If amount exceeds all tiers, use the highest tier fee
  return sortedTiers[sortedTiers.length - 1]?.fee || 0
}
