// LipaOnline TypeScript Types

export interface Admin {
  id: string
  user_id: string
  username: string
  full_name?: string
  is_super_admin: boolean
  created_at: string
  updated_at: string
}

export interface Merchant {
  id: string
  user_id: string
  shop_name: string
  phone: string
  email?: string
  full_name: string
  region?: string
  is_verified: boolean
  is_active: boolean
  wallet_balance: number
  total_sales: number
  total_transactions: number
  referral_code?: string
  referred_by?: string
  subscription_type: 'free' | 'monthly' | 'yearly'
  subscription_expires_at?: string
  custom_branding: boolean
  branding_logo_url?: string
  branding_color?: string
  created_at: string
  updated_at: string
}

export interface Product {
  id: string
  merchant_id: string
  name: string
  description?: string
  price: number
  image_url?: string
  product_type: 'physical' | 'digital'
  digital_file_url?: string
  is_active: boolean
  stock_quantity: number
  slug: string
  total_sold: number
  created_at: string
  updated_at: string
  // Joined fields
  merchant?: Merchant
}

export interface Order {
  id: string
  order_key: string
  product_id: string
  merchant_id: string
  buyer_name: string
  buyer_phone: string
  buyer_location?: string
  amount: number
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled' | 'delivered'
  payment_phone?: string
  payment_provider?: string
  payment_reference?: string
  created_at: string
  updated_at: string
  // Joined fields
  product?: Product
  merchant?: Merchant
}

export interface Transaction {
  id: string
  order_id?: string
  merchant_id?: string
  type: 'sale' | 'withdrawal' | 'fee' | 'referral_commission' | 'subscription'
  amount: number
  fee_amount: number
  net_amount: number
  status: 'pending' | 'completed' | 'failed'
  payment_reference?: string
  description?: string
  created_at: string
  // Joined fields
  order?: Order
  merchant?: Merchant
}

export interface Withdrawal {
  id: string
  merchant_id: string
  amount: number
  fee: number
  net_amount: number
  phone: string
  status: 'pending' | 'approved' | 'processing' | 'completed' | 'rejected'
  admin_note?: string
  processed_by?: string
  processed_at?: string
  created_at: string
  // Joined fields
  merchant?: Merchant
}

export interface Referral {
  id: string
  referrer_id: string
  referred_id: string
  total_earned: number
  created_at: string
  // Joined fields
  referrer?: Merchant
  referred?: Merchant
}

export interface ReferralEarning {
  id: string
  referral_id: string
  transaction_id?: string
  amount: number
  created_at: string
}

export interface Subscription {
  id: string
  merchant_id: string
  plan_type: 'monthly' | 'yearly'
  amount: number
  status: 'active' | 'expired' | 'cancelled'
  starts_at: string
  expires_at: string
  created_at: string
}

export interface SystemSetting {
  id: string
  key: string
  value: unknown
  description?: string
  updated_at: string
}

export interface PaymentLog {
  id: string
  order_id?: string
  type: string
  request_data?: Record<string, unknown>
  response_data?: Record<string, unknown>
  status?: string
  created_at: string
}

// Mongike API Types
export interface MongikePushRequest {
  phone: string
  amount: number
  reference: string
  callback_url?: string
}

export interface MongikePushResponse {
  success: boolean
  message: string
  transaction_id?: string
  reference?: string
}

export interface MongikeCallbackData {
  transaction_id: string
  reference: string
  status: 'success' | 'failed' | 'pending'
  amount: number
  phone: string
  provider?: string
}

// Dashboard Stats
export interface DashboardStats {
  totalMerchants: number
  activeMerchants: number
  totalProducts: number
  totalOrders: number
  completedOrders: number
  totalRevenue: number
  platformFees: number
  pendingWithdrawals: number
  todayOrders: number
  todayRevenue: number
}

export interface MerchantStats {
  totalProducts: number
  totalOrders: number
  completedOrders: number
  pendingOrders: number
  totalSales: number
  walletBalance: number
  totalWithdrawn: number
  referralEarnings: number
}

// Withdrawal Tiers
export interface WithdrawalTier {
  max: number
  fee: number
}

// Form Types
export interface LoginFormData {
  username: string
  password: string
}

export interface MerchantSignupFormData {
  shop_name: string
  phone: string
  email?: string
  full_name: string
  region?: string
  password: string
  referral_code?: string
}

export interface ProductFormData {
  name: string
  description?: string
  price: number
  image_url?: string
  product_type: 'physical' | 'digital'
  digital_file_url?: string
  stock_quantity?: number
}

export interface BuyerFormData {
  buyer_name: string
  buyer_phone: string
  buyer_location?: string
  payment_phone: string
}

export interface WithdrawalFormData {
  amount: number
  phone: string
}
